#ifndef LEX_H
#define LEX_H
#include "tokens.h"

// prototype
int lex(Token *, char *, int);

#endif
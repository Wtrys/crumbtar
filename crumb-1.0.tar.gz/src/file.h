#ifndef FILE_H
#define FILE_H

// prototypes
char *readFile(char *, int);
void writeFile(char *, char *, int);

#endif
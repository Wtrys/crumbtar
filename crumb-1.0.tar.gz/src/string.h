#ifndef STRING_H
#define STRING_H

// prototype
char *parseString(char *);

#endif